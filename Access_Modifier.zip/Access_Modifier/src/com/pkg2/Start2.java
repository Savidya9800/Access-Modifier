package com.pkg2;

public class Start2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Student std = new Student();
		
		std.showStudentDetails();
	}

}
