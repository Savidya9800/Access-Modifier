package com.pkg2;

import com.pkg1.Person;

public class Student extends Person {
	
	public void showStudentDetails() {
		
		name = "Jayalath";
		
		System.out.println("Student Name :"+this.name);
	}
}
 