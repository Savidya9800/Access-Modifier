 package com.pkg1;

public class Person {
	public String name;
	public int age;
	
	public void showPersonDetails() {
		System.out.println("Person name :"+this.name);
		System.out.println("Person Age :"+this.age);
	}
}
