package com.pkg1;

public class Start1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Person psn = new Person();
		
		psn.name = "Savidya";
		psn.age = 25;
		
		psn.showPersonDetails();
	}

}
